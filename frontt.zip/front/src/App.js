import React from 'react';
//import FloatButton from '../components/layout/header/nav/FloatButton';
import './App.css';
import Footer from './components/Layout/Footer/Footer';
import Head from './components/Layout/Header/Head';
import './App.css'
const App = props => (
  <div className="container">
    <div>
      <Head />
      {props.children}
  
    </div>
    <Footer />
  </div>

)
export default App;
