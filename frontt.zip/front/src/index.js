import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';
import { Provider } from 'react-redux';
import { BrowserRouter , Route, Switch } from 'react-router-dom';
import store from './store';
import Home from './components/Home/Home';
import Login from './components/AuthForms/Login';
import Register from './components/AuthForms/Register';
import Taches from './components/Taches/Taches';


ReactDOM.render(
  <Provider store={store}> 
  <BrowserRouter>

    <App>
      <Switch>
        <Route exact path="/" component={Home}/>
        <Route path="/login" component={Login}/>
        <Route path="/register" component={Register}/> 
      <Route path="/taches" component={Taches}/>
      </Switch>
    </App>
  
    </BrowserRouter>
  </Provider>,
  document.getElementById('root')
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
