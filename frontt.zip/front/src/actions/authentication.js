import axios from 'axios'
import { AUTH_FAILURE, LOGIN_USER_SUCCESS, REGISTER_USER_SUCCESS, LOGOUT } from './types'

//login user
export const login = formData => async dispatch =>{
    try {
     const res =  await axios.post("/api/auth/login", formData)
     localStorage.setItem("token", res.data.token);
     dispatch({
         type: LOGIN_USER_SUCCESS,
         payload: res.data
     });

    } catch (error) {
        console.dir(error);
        const response = error.response.data;
        if(Array.isArray(response)){
            response.forEach((err) =>
            {
                alert(err.msg);
            });
        }
        dispatch({
            type: AUTH_FAILURE
        });
    }
}
export const register = registerData => async dispatch => {
   
    const res = await axios.post('/api/auth/register', registerData);
    console.log("inscrip act", res.data);

    dispatch({
        type:REGISTER_USER_SUCCESS,
        payload:res.data
    })
}
export const logout = () => async dispatch => {
    localStorage.removeItem("token");
   dispatch({
       type: LOGOUT,
       payload: {}
   })
}