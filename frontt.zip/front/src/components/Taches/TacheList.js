import React from "react";
import { connect } from "react-redux";
import TacheItem from "./TacheItem";
function TacheList( {tacheTodo}) {

  return (
    <div className="todo-container">
       {tacheTodo.map((el) => (
          <TacheItem  key={el.id} todo={el}/>
          ))} 
      
    </div>
  );
}
const mapStateToProps = (state) => {
  return {
    tacheTodo: state.tacheTodo.todos,
  };
};
export default connect(mapStateToProps)(TacheList);