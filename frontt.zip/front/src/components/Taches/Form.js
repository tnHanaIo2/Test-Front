import React, { useEffect, useState } from "react";
import { connect } from "react-redux";
import { addTodo } from "../../actions/taches";

function Form ({ addTodo }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [todos, setTodos] = useState([]);
  const [display, setDisplay] = useState([]);

  useEffect(() => {
    setTodos(JSON.parse(localStorage.getItem('localStorageTodos')) || []);
    setDisplay(JSON.parse(localStorage.getItem('localStorageTodos')) || []);
  }, []);

  // const setLocalStorage = (dataSaveInLS) => {
  //   setTodos(dataSaveInLS);
  //   setDisplay(dataSaveInLS);
  //   localStorage.setItem('localStorageTodos', JSON.stringify(dataSaveInLS));
  // };

  const handleSubmit = (event) => {
    event.preventDefault();
    const newTodo = {
      title: title,
      description:description,
      id: Date.now(),
      isComplete: false,
    };
    addTodo(newTodo);
    const dataSaveInLS = [...todos, newTodo];
    setTitle("");
    setDescription("");
    //setLocalStorage(dataSaveInLS);


  };

  return (
    <div className="add-todo-container">
    <h2> Créer une nouvelle tâche:</h2>
    <form onSubmit={handleSubmit}>

    <div class="row" style={{display:"inline"}}>
  <div class="col-4"> <input required
        placeholder="Nom de la tâche"
        type="text"
            value={title}
          onChange={(e) => setTitle(e.target.value)}
        className="todo-input"
      /></div>
  <div class="col-6">           <input required
        placeholder="Description de la tâche"
        type="text"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
        className="todo-input"
      /></div>
  <div class="col-2">    <button  className="todo-button" type="submit">Ajouter la tâche
      </button></div>

</div>
    </form>
  </div>
  );
}
export default connect(null, { addTodo })(Form);


