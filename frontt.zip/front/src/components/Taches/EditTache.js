import React, { Fragment, useState, useEffect } from "react";
import { connect } from "react-redux";
import Modal from "react-modal";
import { editTask } from "../../actions/taches";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)",
  },
};

Modal.setAppElement("#root");


function EditTache({ oldTodo, editTask }) {
  const [isOpen, setIsOpen] = useState(false);
  const [title, setTitle] = useState(oldTodo.title);
  const [description, setDescription] = useState(oldTodo.description);

  useEffect(() => {
    setTitle(oldTodo.title);
  }, [isOpen, oldTodo.title]
  );
  useEffect(() => {
    setDescription(oldTodo.description);
  },
 [isOpen, oldTodo.description]
  );
  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    // if (title.trim() === "") {
    //   return alert("Vueillez ...");
    // }
    const newTodo = { ...oldTodo, title: title, description:description };
    editTask(newTodo);
    toggleModal();
  };

  return (
    <Fragment>
      <button onClick={toggleModal}>Modifier</button>
      <Modal isOpen={isOpen} style={customStyles} onRequestClose={toggleModal}>
        <form onSubmit={handleSubmit}>
          <input
            value={title}
            type="text"
            onChange={(e) => setTitle(e.target.value)}
            required
          />
            <input
            value={description}
            type="text"
            onChange={(e) => setDescription(e.target.value)}
            required
          />
          <button type="submit"> Confirmer </button>
          <button onClick={toggleModal}> Annuler </button>
        </form>
      </Modal>
    </Fragment>
  );
};

export default connect(null, { editTask })(EditTache);
