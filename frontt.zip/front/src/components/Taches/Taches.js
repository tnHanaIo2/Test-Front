import React from "react";
import Form from "./Form";
import TacheList from "./TacheList";
function Taches() {

  return (
    <div>
    <h2 style={{textAlign:"center"}}>Liste des Tâches:
</h2>
    <TacheList />
    <Form />
  </div>
  );
}
export default Taches;