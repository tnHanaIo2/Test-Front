
import React from "react";
import { connect } from "react-redux";
import { Button} from 'react-bootstrap';
import EditTache from "./EditTache";
import { toggleComplete, removeTodo, editTask } from "../../actions/taches";

function TacheItem({ todo, toggleComplete, removeTodo }) {

  return (
    <div className="todo-card">
      <p
        style={
          todo.isComplete
            ? { textDecoration: "line-through", opacity: "0.3" }
            : {}
        }
      >
       <b> {todo.title}</b>:&nbsp; 
        {todo.description}
      </p>
      <div>
      {todo.isComplete ?  <Button variant="danger" onClick={() => toggleComplete(todo.id)}>
          {todo.isComplete ? "Non Complétée" : "Complétée"}
        </Button> :
        <Button variant="success" onClick={() => toggleComplete(todo.id)}>
          {todo.isComplete ? "Non Complétée" : "Complétée"}
        </Button>}
        {/* <button onClick={() => toggleComplete(todo.id)}>
          {todo.isComplete ? "Non Complétée" : "Complétée"}
        </button> */}
        <button onClick={() => removeTodo(todo.id)}>Supprimer</button>
        <EditTache oldTodo={todo} />
      </div>
    </div>
  );
}
export default connect(null, { toggleComplete, removeTodo, editTask })(TacheItem);
