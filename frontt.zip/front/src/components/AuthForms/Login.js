 
import React,{ useState} from 'react'
import { connect, useDispatch } from 'react-redux'
import {login} from '../../actions/authentication'
import './auth.css' 
import LoginForm from './LoginForm'

const Login = ({history}) => {

     const dispatch = useDispatch();
     const [formData, setFormData] = useState({
       email: "",
       password:""
     });

     const hundleChange = (e) => {
       setFormData({ ...formData, [e.target.name]: e.target.value })

     }

     const hundleSubmit = (e) => {
       e.preventDefault();
      /// this.props.login(formData);
    //  this.props.login(formData);
    dispatch (login(formData));  
      // console.log("formData here",dispatch(login(formData)))
       history.push("/");
     }
    return(
      <div>
      
        <div className="forms">
          <h2 style={{textAlign:"center"}}> Connexion</h2>
          <LoginForm   email = {formData.email}
            password = {formData.password}
            hundleSubmit = {hundleSubmit}
            hundleChange = {hundleChange}/>
        </div>
    
        {/* <div >
     <p>Vous n'avez pas encore de compte? </p>
         <Link to="/register">S'inscrire</Link>
     </div> */}
      </div>
    )
  }

 const mapStateToProps = state => (
   {

     auth : state.auth


 }
 )

export default connect ( mapStateToProps)(Login);