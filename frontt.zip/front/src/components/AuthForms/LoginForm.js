import React from 'react';
import TEXTFieldInput from '../common/input/TextField';

const LoginForm = ({hundleChange, hundleSubmit, email, password}) => (

    <form className="auth-form" onSubmit={hundleSubmit}>
    <TEXTFieldInput
        type = "email"
        name = "email"
        placeholder = "Email"
        value = {email}
        onChange = {hundleChange}
    />
    <TEXTFieldInput
           type = "password"
           name = "password"
           placeholder="Password"
           value = {password}
           onChange = {hundleChange}
    />
    <button style={{textAlign:"center"}} type="submit">Login</button>
</form>

)



export default LoginForm;