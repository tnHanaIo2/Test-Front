import React from 'react';
import TextFieldInput from "../common/input/TextField";

const SignUpForm = ({name, lastName, email, password, confirmPassword, hundlerChange, hundleSubmit}) => (
    <form className="auth-form" onSubmit={hundleSubmit} >
     <TextFieldInput
        type="text"
        name="name"
        placeholder="Nom"
        value={name}
        onChange={hundlerChange}

    />
       <TextFieldInput
        type="text"
        name="lastName"
        placeholder="Prénom"
        value={lastName}
        onChange={hundlerChange}

    />
    <TextFieldInput
        type="email"
        name="email"
        placeholder="Email"
        value={email}
        onChange={hundlerChange}
    />
    <TextFieldInput
        type="password"
        name="password"
        placeholder="Password"
        value={password}
        onChange={hundlerChange}

    />
    <TextFieldInput
        type="password"
        name="confirmPassword"
        placeholder="Confirm Password"
        value={password}
        onChange={hundlerChange}

    />
    <button>Sign In</button>
    </form>
)
export default SignUpForm;