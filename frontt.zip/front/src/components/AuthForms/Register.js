import React, {Component}from 'react';
import { connect } from 'react-redux';
import SignUpForm from './SignUpForm';
import {register} from '../../actions/authentication';


class Register extends Component
{
  state={
    name:"",
    lastName:"",
    email:"",
    password:"",
    confirmPassword:"",
  }
 componentDidMount (){
  if(this.props.auth.isAuth){
    this.props.history.push("/");
  }
}
   hundlerChange = e => {
     this.setState( {[e.target.name] : e.target.value})
  }
   hundleSubmit = async e => {

     e.preventDefault();
     const user={
      name: this.state.name,
      lastName: this.state.lastName,
      email: this.state.email,
      password: this.state.password,
      confirmPassword: this.state.confirmPassword,
     }
      console.log("user comp", user);
     this.props.register(user);
     this.props.history.push('/login')
  }
render(){
  const {name, lastName, email, password, confirmPassword} = this.state;
  return(
    <div className="forms">
    <h2>Inscription</h2>
    <SignUpForm
    name={name}
    lastName={lastName}
    email={email}
    password={password}
    confirmPassword={confirmPassword}
    hundlerChange={this.hundlerChange}
    hundleSubmit={this.hundleSubmit}
    />

    </div>
  )
}
}
const mapStateToProps = state =>({
  auth: state.auth
})
export default connect(mapStateToProps, {register})(Register);