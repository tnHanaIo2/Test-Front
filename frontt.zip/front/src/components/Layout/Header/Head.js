import React from "react";
import "./Head.css";
import NavBar from "./nav/NavBar";
import NavTaches from "./nav/NavTaches";
import { Link } from "react-router-dom";
import { connect, useSelector } from "react-redux";

const Head = () => {
  const isAuth = useSelector((state) => state.auth.isAuth);
  return (
  <div className="sticky">
    <header>
      <figure>
      <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTeqIGbZGNYSwxnb3GN6Mj6p4znEpH7ohcDhQ&usqp=CAU" alt="not found" />

      </figure>
      <h1>
        <Link to="/">Accueil</Link>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
        {isAuth ? <Link to="/taches">Tâches</Link> : <Link to="/login">Tâches</Link>}


      </h1>
      <NavTaches />
      <NavBar />
    </header>
  </div>
  );
}
const mapStateToProps = state => ({
  auth: state.auth
})
export default connect(mapStateToProps) (Head);
