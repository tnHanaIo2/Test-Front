import React, {Component} from 'react'


class FloatButon extends Component {
 render(){
     return(
         <div className="circular-menu">
         
            <menu className="items-wrapper">
        
            </menu>
         </div>
     )
 }
}



export default FloatButon;