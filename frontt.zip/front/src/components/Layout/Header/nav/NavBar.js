import React from "react";
import './NavBar.css'
import { Link } from 'react-router-dom'
import { connect, useDispatch, useSelector } from "react-redux";
import { logout } from "../../../../actions/authentication";

const  NavBar =() => {
    const dispatch= useDispatch();

    const hundleOnClick = () => {
        dispatch(logout());
    }
      const isAuth = useSelector((state) => state.auth.isAuth);
  
        const guestLinks = (<ul className='guestLinks'>
            <li>
               <Link to="/register">S'inscrire</Link> 
            </li>
            <li>
                <Link to="/login">Se connecter</Link>
            </li>
        </ul>)
        const authLinks = (<ul className='authLinks'>
            <li>

            {/* { user.role === "admin" ?  <Link to="/dashboard">Espace Admin</Link> :null}
             {user.role === "user" ? <Link to="/client/profil">Mon Profil</Link> : null}    */}
            </li>
            <li>
          <Link to="" onClick={hundleOnClick}>
            Déconnexion{" "}
          </Link>
        </li>
        </ul>)
        return (
            <div>
                <nav className="nav-bar nav-two">
                     { !isAuth ? guestLinks : authLinks}  
                
             
                </nav>
            </div>
        )
    }
const mapStateToProps = state => ({
    auth: state.auth
})
export default connect(mapStateToProps) (NavBar);