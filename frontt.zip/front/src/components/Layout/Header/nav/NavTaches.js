import React from "react";

import { connect, useSelector } from "react-redux";

const NavTaches =() =>{

  
    const isAuth = useSelector((state) => state.auth.isAuth);

    return (
      <div style={{color:"white"}} >
      {/* {isAuth ? <Link to="/taches">Tâches</Link> : <Link to="/login">Tâches</Link>} */}
        

       
      </div>
    );
  
}

const mapStateToProps = state => ({
  auth: state.auth
})
export default connect(mapStateToProps) (NavTaches);

