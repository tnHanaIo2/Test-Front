import React, { Component } from 'react'
import { connect } from 'react-redux';
import {getAllProducts} from '../../../../actions/productAction';
import './Home.css';

class Home extends Component {
    async componentDidMount() {
        if (this.props.auth.isAuthenticated &&
            this.props.auth.user.isAdmin &&
            this.props.auth.user.role === 'admin') {
            this.props.history.push("/dashboard");
        }
        await this.props.getAllProducts();
    }

        render() {
            const {products} = this.props.product

            return (
                <div className='home-container'>
                    <section id="showcase" className="grid">
                        <div className="bg-image"></div>
                        <div className="content-wrap">
                            <h1>Bienvenue dans e-Lubrifiants</h1><br/>
                            <h2 style={{color:"purple"}}>Vente & Réservation En Ligne</h2>
<h3 style={{color:"purple"}}>
e-Lubrifiants mini site web abordable de couvrir l'Afrique du Nord, 
en cours de developpement et de croissance.
 </h3>
                            <a href="#section-b" className="btn">Voir Plus</a>
                        </div>
                    </section>
    
                    <main id="main">
    
                        <section id="section-a" className="grid">
                            <div className="content-wrap">
                                <h2 className="content-title">e-Lubrifiants - Vente & Réservation En Ligne </h2>
                                <div className="content-text">
                                    <p>"e-Lubrifiants" Compte 3 collaborateurs et génère 10 emplois indirects ; ses activités sont réparties sur 2 sites industriels et plus de 2 stations-service dédiées à la distribution de carburants.</p>
                                </div>
                            </div>
                        </section>
                        <section id="section-c" className="grid">
                            <div className="content-wrap">
                                <h1 className="content-title">Nos Produits</h1>
                                <p>Nous proposons une large gamme de produits dans divers catégories , tous disponibles avec des remise si intéréssants</p>
                            </div>
                        </section>
                        <section id="section-b" className="grid">
                                              <ul>
                            {products.slice(0,3).map((item) => {
                            return(
                                <li className="borderlist">
                                <div className="card">
                                    <img className="img-home" src={item.image} alt="" />
                                    <div className="card-content">
                                        <h3 className="card-title">{item.name}</h3>
                                        <p>{item.description.slice(0,20)}...</p>
                                    </div>
                                </div>
                            </li>
                            )
                        })}  
                    
                            </ul>

                        </section>
                        <a href={`/products/category/all`} className="btn">Voir Plus</a>

                       
                        <section id="section-d" className="grid">
                            <div className="box">
                                <h2 className="content-title">Contactez Nous</h2>
                                e-Lubrifiants mini site web abordable de couvrir l'Afrique du cours, en cours de developpement et de croissance.

<p>                                <i class="fas fa-envelope-square">&nbsp;&nbsp;e-Lubrifiants@gmail.com</i>
</p>   
<p>  <i class="fas fa-phone">&nbsp;&nbsp;+216 98 147 856</i></p>                           

                            </div>
                            <div className="box">
                                <h2 className="content-title">A propos de notre mini site</h2>
                                <p><strong>"e-Lubrifiants" </strong>Compte 3 collaborateurs et génère 10 emplois indirects ; ses activités sont réparties sur 2 sites industriels et  plus de 2 stations-service dédiées à la distribution de carburants.

<br></br>E-Lubrifiants continue de développer ses activités afin de confirmer sa présence dans les domaines des Lubrifiants & Gaz.
</p>
                            </div>
                        </section>
                    </main>
                </div>
            )
        }
    }
                     

const mapStateToProps = state => ({
    auth: state.auth,
    product: state.product
})
export default connect(mapStateToProps , {getAllProducts})(Home);

