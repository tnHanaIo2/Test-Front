import React from 'react';

import './Footer.css';

const Footer = () => (
    <div>
        <footer>
            <p>
                {<>&copy;</>}Test Front
                <a
                    href="https://github.com/elPoeta"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <i className="fab fa-react fa-2x " />&nbsp;&nbsp;
                    Developed By Hana Ben Hammouda
        </a>{" "}
                {new Date().getFullYear()}
            </p>
        </footer>
    </div>
);

export default Footer;
