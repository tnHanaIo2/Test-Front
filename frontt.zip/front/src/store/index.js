import { applyMiddleware, compose, createStore } from "redux";
import thunk from 'redux-thunk'
import rootReducers from "../reducers";
const devTools=    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()

const persistedState = localStorage.getItem('Storage_Taches') ? JSON.parse(localStorage.getItem('tacheTodo')) : {}

const store = createStore(rootReducers,  compose
    (applyMiddleware(thunk),
    devTools
    ),
    //devTools 
    );
    store.subscribe(() => {
       console.log("here tacheTodo", store.getState());
         localStorage.setItem('Storage_Taches', JSON.stringify(store.getState()))
       })
export default store;