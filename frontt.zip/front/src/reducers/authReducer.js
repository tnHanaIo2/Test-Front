import {LOGIN_USER_SUCCESS, REGISTER_USER_SUCCESS, LOGOUT} from '../actions/types'

const initialState = {
    token: '',
    user:{},
    isLoading: false,
    isAuth: false
};

export default (state = initialState, action) => {
    switch(action.type) {
         case LOGIN_USER_SUCCESS:
         return {...state,
                 user: action.payload.user,
                 token: action.payload.token,
                 isLoading: false,
                 isAuth: true,
                         
        };
        case REGISTER_USER_SUCCESS:
            return {
                ...state,
                user:action.payload.user,
                token: action.payload.token,
                isLoading: false,
                isAuth: false,

            };
        case LOGOUT: 
        return {
             ...state,
             isAuth:false,
             isLoading:false,
             user:{},
             token:''
        } 
        default:
            return state;
    }

};

