import {combineReducers} from 'redux';
import authReducer from './authReducer';
import tacheReducer from './tacheReducer';


const rootReducers = combineReducers({
    auth: authReducer,
    tacheTodo: tacheReducer,

})

export default rootReducers;